package com.twilio.src

public  class CustomViewProps {
  companion object {
    val TOKEN = "token"
    val ROOM_NAME = "roomName"
  }
}
